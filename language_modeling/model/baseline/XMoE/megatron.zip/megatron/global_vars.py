# Copyright (c) 2022, NVIDIA CORPORATION. All rights reserved.

"""Megatron global variables."""

import os
import sys
import torch

from megatron import dist_signal_handler
from megatron.tokenizer import build_tokenizer
from .microbatches import build_num_microbatches_calculator
from .timers import Timers

import argparse

_GLOBAL_ARGS = None
_GLOBAL_RETRO_ARGS = None
_GLOBAL_NUM_MICROBATCHES_CALCULATOR = None
_GLOBAL_TOKENIZER = None
_GLOBAL_TENSORBOARD_WRITER = None
_GLOBAL_ADLR_AUTORESUME = None
_GLOBAL_TIMERS = None
_GLOBAL_SIGNAL_HANDLER = None

def get_args():
    """Return arguments."""
    _ensure_var_is_initialized(_GLOBAL_ARGS, 'args')
    return _GLOBAL_ARGS

def get_args1():
    ##下面的内容用于XMoE的参数初始化
    parser = argparse.ArgumentParser(description='PyTorch Transformer Language Model')
    parser.add_argument('--fp16', action='store_true', help='Run in pseudo-fp16 mode (fp16 storage fp32 math).')
    parser.add_argument('--deepspeed', action='store_true', help='Use DeepSpeed for training.')
    parser.add_argument('--no-pipeline-parallel', action='store_true', help='Disable pipeline parallelism.')

    # 浮点数参数
    parser.add_argument('--adam-beta1', type=float, default=0.9, help='Beta1 for Adam optimizer.')
    parser.add_argument('--adam-beta2', type=float, default=0.95, help='Beta2 for Adam optimizer.')
    parser.add_argument('--moe-loss-coeff', type=float, default=0.01, help='Loss coefficient for MoE.')
    parser.add_argument('--moe-train-capacity-factor', type=float, default=1.0, help='MoE training capacity factor.')
    parser.add_argument('--moe-eval-capacity-factor', type=float, default=1.0, help='MoE evaluation capacity factor.')
    parser.add_argument('--init-method-std', type=float, default=0.014,
                        help='Initialization method standard deviation.')
    # parser.add_argument('--lr', type=float, default=4.5e-4, help='Learning rate.')
    parser.add_argument('--min-lr', type=float, default=4.5e-6, help='Minimum learning rate.')

    # 整型参数
    parser.add_argument('--tensor-model-parallel-size', type=int, default=1, help='Tensor model parallel size.')
    parser.add_argument('--moe-expert-parallel-size', type=int, default=-1, help='MoE expert parallel size.')
    parser.add_argument('--num-experts', type=int, default=64, help='Number of experts.')
    parser.add_argument('--num-layers', type=int, default=12, help='Number of layers in the model.')
    parser.add_argument('--hidden-size', type=int, default=768, help='Hidden size of the model.')
    parser.add_argument('--num-attention-heads', type=int, default=12, help='Number of attention heads.')
    parser.add_argument('--max-position-embeddings', type=int, default=2048, help='Max position embeddings.')
    parser.add_argument('--seq-length', type=int, default=2048, help='Sequence length.')
    parser.add_argument('--global-batch-size', type=int, default=256, help='Global batch size.')
    parser.add_argument('--micro-batch-size', type=int, default=4, help='Micro batch size.')
    parser.add_argument('--num-workers', type=int, default=0, help='Number of workers for data loading.')

    # 字符串参数
    parser.add_argument('--load', type=str, default=None, help='Path to load the model.')
    parser.add_argument('--save', type=str, default=None, help='Path to save the model.')
    parser.add_argument('--tensorboard-dir', type=str, default='./tensorboard', help='Directory for tensorboard logs.')
    # parser.add_argument('--data-path', type=str, required=True, help='Path to the data.')
    # parser.add_argument('--vocab-file', type=str, required=True, help='Path to the vocabulary file.')
    # parser.add_argument('--merge-file', type=str, required=True, help='Path to the merges file.')
    # parser.add_argument('--deepspeed_config', type=str, required=True, help='Path to the DeepSpeed configuration file.')

    # 其他参数
    # parser.add_argument('--lr-decay-tokens', type=int, default=300000000000, help='Tokens for learning rate decay.')
    # parser.add_argument('--lr-warmup-tokens', type=int, default=375000000, help='Tokens for learning rate warmup.')
    parser.add_argument('--train-tokens', type=int, default=300000000000, help='Tokens for training.')
    parser.add_argument('--train-iters', type=int, default=1716613, help='Training iterations.')
    parser.add_argument('--clip-grad', type=float, default=1.0, help='Gradient clipping value.')
    parser.add_argument('--weight-decay', type=float, default=0.1, help='Weight decay coefficient.')
    # parser.add_argument('--log-interval', type=int, default=10, help='Logging interval.')
    # parser.add_argument('--eval-interval', type=int, default=100, help='Evaluation interval.')
    parser.add_argument('--eval-iters', type=int, default=10, help='Evaluation iterations.')
    parser.add_argument('--save-interval', type=int, default=10000, help='Model save interval.')
    parser.add_argument('--exit-duration-in-mins', type=int, default=30000000, help='Exit duration in minutes.')

    _GLOBAL_ARGS = parser.parse_args()

    return _GLOBAL_ARGS


def get_retro_args():
    """Return retro arguments."""
    return _GLOBAL_RETRO_ARGS


def get_num_microbatches():
    return _GLOBAL_NUM_MICROBATCHES_CALCULATOR.get()


def get_current_global_batch_size():
    return _GLOBAL_NUM_MICROBATCHES_CALCULATOR.get_current_global_batch_size()


def update_num_microbatches(consumed_samples, consistency_check=True):
    _GLOBAL_NUM_MICROBATCHES_CALCULATOR.update(consumed_samples,
                                               consistency_check)


def get_tokenizer():
    """Return tokenizer."""
    _ensure_var_is_initialized(_GLOBAL_TOKENIZER, 'tokenizer')
    return _GLOBAL_TOKENIZER


def get_tensorboard_writer():
    """Return tensorboard writer. It can be None so no need
    to check if it is initialized."""
    return _GLOBAL_TENSORBOARD_WRITER


def get_adlr_autoresume():
    """ADLR autoresume object. It can be None so no need
    to check if it is initialized."""
    return _GLOBAL_ADLR_AUTORESUME


def get_timers():
    """Return timers."""
    _ensure_var_is_initialized(_GLOBAL_TIMERS, 'timers')
    return _GLOBAL_TIMERS


def get_signal_handler():
    _ensure_var_is_initialized(_GLOBAL_SIGNAL_HANDLER, 'signal handler')
    return _GLOBAL_SIGNAL_HANDLER


def _set_signal_handler():
    global _GLOBAL_SIGNAL_HANDLER
    _ensure_var_is_not_initialized(_GLOBAL_SIGNAL_HANDLER, 'signal handler')
    _GLOBAL_SIGNAL_HANDLER = dist_signal_handler.DistributedSignalHandler().__enter__()



def set_global_variables(args):
    """Set args, tokenizer, tensorboard-writer, adlr-autoresume, and timers."""

    assert args is not None

    _ensure_var_is_not_initialized(_GLOBAL_ARGS, 'args')
    set_args(args)

    _build_num_microbatches_calculator(args)
    _ = _build_tokenizer(args)
    _set_tensorboard_writer(args)
    _set_adlr_autoresume(args)
    _set_timers(args)

    if args.exit_signal_handler:
        _set_signal_handler()
    

def set_args(args):
    global _GLOBAL_ARGS
    _GLOBAL_ARGS = args


def set_retro_args(retro_args):
    global _GLOBAL_RETRO_ARGS
    _GLOBAL_RETRO_ARGS = retro_args


def _build_num_microbatches_calculator(args):

    global _GLOBAL_NUM_MICROBATCHES_CALCULATOR
    _ensure_var_is_not_initialized(_GLOBAL_NUM_MICROBATCHES_CALCULATOR,
                                   'num microbatches calculator')

    _GLOBAL_NUM_MICROBATCHES_CALCULATOR = build_num_microbatches_calculator(
        args)


def _build_tokenizer(args):
    """Initialize tokenizer."""
    global _GLOBAL_TOKENIZER
    _ensure_var_is_not_initialized(_GLOBAL_TOKENIZER, 'tokenizer')
    _GLOBAL_TOKENIZER = build_tokenizer(args)
    return _GLOBAL_TOKENIZER


def rebuild_tokenizer(args):
    global _GLOBAL_TOKENIZER
    _GLOBAL_TOKENIZER = None
    return _build_tokenizer(args)


def _set_tensorboard_writer(args):
    """Set tensorboard writer."""
    global _GLOBAL_TENSORBOARD_WRITER
    _ensure_var_is_not_initialized(_GLOBAL_TENSORBOARD_WRITER,
                                   'tensorboard writer')

    if hasattr(args, 'tensorboard_dir') and \
       args.tensorboard_dir and args.rank == (args.world_size - 1):
        try:
            from torch.utils.tensorboard import SummaryWriter
            print('> setting tensorboard ...')
            _GLOBAL_TENSORBOARD_WRITER = SummaryWriter(
                log_dir=args.tensorboard_dir,
                max_queue=args.tensorboard_queue_size)
        except ModuleNotFoundError:
            print('WARNING: TensorBoard writing requested but is not '
                  'available (are you using PyTorch 1.1.0 or later?), '
                  'no TensorBoard logs will be written.', flush=True)


def _set_adlr_autoresume(args):
    """Initialize ADLR autoresume."""
    global _GLOBAL_ADLR_AUTORESUME
    _ensure_var_is_not_initialized(_GLOBAL_ADLR_AUTORESUME, 'adlr autoresume')

    if args.adlr_autoresume:
        if args.rank == 0:
            print('enabling autoresume ...', flush=True)
        sys.path.append(os.environ.get('SUBMIT_SCRIPTS', ''))
        try:
            from userlib.auto_resume import AutoResume
        except BaseException:
            print('ADLR autoresume is not available, exiting ...')
            sys.exit()

        _GLOBAL_ADLR_AUTORESUME = AutoResume


def _set_timers(args):
    """Initialize timers."""
    global _GLOBAL_TIMERS
    _ensure_var_is_not_initialized(_GLOBAL_TIMERS, 'timers')
    _GLOBAL_TIMERS = Timers(args.timing_log_level, args.timing_log_option)


def _ensure_var_is_initialized(var, name):
    """Make sure the input variable is not None."""
    assert var is not None, '{} is not initialized.'.format(name)


def _ensure_var_is_not_initialized(var, name):
    """Make sure the input variable is not None."""
    assert var is None, '{} is already initialized.'.format(name)
